
console.log("%c general.js CALLED", "padding:5px 10px;margin:5px;color: #333;border-left:5px solid #F88F79;");

$(document).ready(function() {


});
